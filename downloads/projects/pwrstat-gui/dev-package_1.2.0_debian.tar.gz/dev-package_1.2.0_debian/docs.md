## Folder Structure

pwrstat-gui_x.y.z
 - `DEBIAN`
     - `control` package installation information
     - `preinst` run before installation, checks for existing settings
     - `postinst` run after installation, copies existing settings
     - `postrm` runs after removal, removes leftover files, only needed after
       broken installs
 - `usr` this folder and its children will be installed at /usr
     - `bin`
         - `pwrstat-gui` the executable for the package
     - `share`
         - `applications`
             - `pwrstat-gui.desktop` the .desktop file for your taskbar and
               desktop
         - `doc`
             - `pwrstat-gui` various documentation files
                 - `CHANGELOG.md` a copy of the changelog found on GitHub
                 - `copyright` copyright and license notice
                 - `README.md` a copy of the readme found on GitHub
         - `icons` package icons for taskbar, menus, etc.
             - `hicolor`
                 - `512x512`
                     - `apps`
                         - `pwrstat-gui.png` logo, png format
                 - `scalable`
                     - `pwrstat-gui.svg` logo, svg format

<br/>

## Instructions to Build a .deb Package

First, you have to compile the Python program. The Python program must be
compiled on the oldest system you want it to be compatible with (programs
compiled on older systems work on newer ones, but not the other way around).
Specifically, the package seems to break when the user has an older version of
GLIBC (you can check yours with `ldd --version`). I compile on Linux Mint 22.2,
using GLIBC v2.39.

You can compile the program using the included file `pwrstat-gui-compiler.sh`.
Place your main.py in the same directory, and run the sh file. It will create
a Python virtual environment (compiler-venv) to compile the project in. This
directory will not be deleted afterwards, but you can manually delete it if you
wish.

Next you need to build the package. Place the required files with the same
directory setup as pwrstat-gui_x.y.z, and use the command
`dpkg -b pwrstat-gui_x.y.z` to build the package.