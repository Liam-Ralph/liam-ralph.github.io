#!/bin/sh

if [ -f main.py ]; then

    # Python file found

    echo "\nInstalling required packages..."
    apt install python3 python3-venv python3-tk python3-pil python3-pil.imagetk python3-setproctitle

    echo "\nCreating virtual environment..."
    python3 -m venv compiler-venv
    mkdir compiler-venv/pyinstaller-files
    cp main.py compiler-venv/pyinstaller-files/pwrstat-gui.py

    echo "\nInstalling pip packages..."
    cd compiler-venv
    bin/python3 -m pip install pyinstaller pillow tk setproctitle

    echo "\nCompiling Python program..."
    bin/python3 -m PyInstaller --onefile --distpath=pyinstaller-files/dist \
        --workpath=pyinstaller-files/build --hidden-import=PIL \
        --hidden-import=PIL._tkinter_finder pyinstaller-files/pwrstat-gui.py

    echo "\nCopying executable..."
    cd ..
    cp compiler-venv/pyinstaller-files/dist/pwrstat-gui pwrstat-gui

    echo "\nCompilation complete.\nYou may delete compiler-venv, or re-use it."

else

    # No Python file found
    echo "main.py not found, exiting now."

fi