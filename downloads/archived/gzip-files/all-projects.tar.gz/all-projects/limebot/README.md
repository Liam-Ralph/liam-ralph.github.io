# This project has been archived.

# LimeBot
### Released June 2022
### Version 2.7

<br/>

## Description
LimeBot is a Discord bot made using the discord.py
library. It has a number of simple commands for
interacting with the bot, account management, and
administrator management. LimeBot can store information
about the users it interacts with to save their settings,
position on the "commands ran" leaderboard, and
whether they've read the latest administrator
announcement.

## Notes
Some files are not published to GitHub for the protection of sensitive data.