## This project has been archived

# The Random Trivia Game
### Released July 2022

<br/>

## Description
A simple text-based trivia game in Java. Answer questions about
random trivia and try to beat the high score.
