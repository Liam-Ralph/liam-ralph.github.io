## This project has been archived

# MapGen 4
### Released July 2022

<br/>

## Description
MapGen 4 is a map generation algorithm that displays
its output using the turtle.py library. It generates
rock, land, sand, and water of varying height and depth,
and can use a number of colour presets to change the map's
appearance.
