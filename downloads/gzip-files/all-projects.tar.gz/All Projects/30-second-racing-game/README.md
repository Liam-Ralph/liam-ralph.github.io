## This project has been archived.

# 30 Second Racing Game
### Released August 2022

<br/>

## Description
A simple 2D racing game using the p5.js library. As the name suggests, the
game lasts approximately 30 seconds. Attempt to reach the finish line as fast
as possible without crashing to set the high score. Use arrow keys to control
car rotation and direction. The high score is not updated automatically,
message me with a screenshot of your time to have it updated.
