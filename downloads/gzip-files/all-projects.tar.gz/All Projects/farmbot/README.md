## This project has been archived.

# FarmBot
### Released July 2022
### Version 2.0 (in progress)

<br/>

## Description
A Discord bot written in Python, with a variety of commands related to
farming, account creation and management, and administrator permissions.
Currently unfinished, as many commands have not been completed.

<br/>

## Notes
Some files are not published to GitHub for the protection of sensitive data.
