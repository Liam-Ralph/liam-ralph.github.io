## This project has been archived

# Kingdom of War - Multiplayer
### Released June 2022
### Version 1.1

<br/>

## Description
Kingdom of War - Multiplayer is the sequel to Kingdom of War. Both are
text-based console strategy games. The sequel includes local multiplayer
and a new map, but does not include a computer-controlled opponent or
any form of money. Players can gain and deploy troops, invade territories,
and conquer all opponents' territory to win.
