# This project has been archived.

# Kingdom of War
### Released May 2022
### Version 1.2

<br/>

## Description
A text-based console game written in Python. Win by conquering all
of your opponent's territories. The opponent is a computer-controlled
algorithm, and while beatable, it is fairly good at the game. Turns
include gaining soldiers, deploying soldiers, and invading other
territories.
