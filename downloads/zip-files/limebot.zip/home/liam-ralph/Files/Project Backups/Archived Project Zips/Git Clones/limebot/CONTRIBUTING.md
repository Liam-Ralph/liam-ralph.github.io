## This project has been archived.

# Contributing
This is a personal project, and does not need outside contribution.
As some of my personal projects are from earlier on in my programming journey, 
you may notice inefficient code, bad practices, and a blatant disrespect for convention.
This is fine, and in most cases I don't intend on fixing it.