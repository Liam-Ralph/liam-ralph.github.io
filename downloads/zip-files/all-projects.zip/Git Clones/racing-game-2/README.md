## This project has been archived.

# Racing Game 2
### Released November 2022

<br/>

## Description
A sequel to 30 Second Racing Game, with an incredibly creative name.
An online racing game using the p5.js library. Control your car's
direction and speed to avoid obstacles and beat the high score.
The high score is not updated automatically, message me with a
screenshot of your time to have it updated.
