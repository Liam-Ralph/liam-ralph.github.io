## This project has been archived.

# Exorcist
### Released July 2022

<br/>

## Description
A text-based console game made in Java. Explore a mysterious
series of rooms, in which a number of dark secrets hide.
Uses the common text-based mechanic of choosing the player's
course from a number of options, with no graphical representation
of the situation.
