## This project has been archived

# MapGen 5
### Released January 2023

<br/>

## Description
A Python map generation tool, and the sequel to MapGen 4, now
providing output with colored text or the turtle.py library.
Generates rock, land, sand, and water of varying height and
depth, with more customization options for map color presets
than previously available.
