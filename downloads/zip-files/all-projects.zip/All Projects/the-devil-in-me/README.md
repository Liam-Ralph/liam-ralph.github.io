## This project has been archived.

# The Devil in Me
### Released June 2022

<br/>

## Description
A simple game made using the p5.js library. Switch between
modes and use magic to defeat enemies and score points until
your inevitable death. The high score is not updated automatically,
message me with a screenshot to have it updated.
