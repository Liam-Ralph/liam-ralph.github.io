# Changelog

<br/>

## v1.2
### Fixed Possible Null Value
 - Possible null value for islandNumMultiplier fixed instead of disabling warning
### Added Function Description
 - Added function summary for RandomList()
### Minor Improvements

<br/>

## v1.1
### Added Functions
 - GetInt()
 - RandomList()
### Added Function Descriptions
 - CheckAdjacent()
 - CheckAdjacentExact()
 - ClearLine()
 - Expand()
 - GetInt()
 - LoadingBar()
### Changed Expand() Function
### Convention Improvements
### Minor Improvements

<br/>

## v1.0
The orginal release of WorldGen.
