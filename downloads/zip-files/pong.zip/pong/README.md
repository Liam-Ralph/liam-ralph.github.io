## This project has been archived.

# Pong
### Released August 2022

<br/>

## Description
A online game similar to Pong. Play against a computer opponent,
scoring points until one is score on you, ending the game. Pong is
written using the p5.js library, and integrated within a regular
website.
