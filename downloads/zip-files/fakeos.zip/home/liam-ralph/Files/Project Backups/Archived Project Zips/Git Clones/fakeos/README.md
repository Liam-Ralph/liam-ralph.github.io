## This project has been archived

# FakeOS
### Released September 2022

<br/>

## Description
A text-based games impersonating an operating system. Explore a variety
of applications and features, while trying to earn FakeCoin and avoid
catching a virus or losing your assets. Includes a money system, a
simulated stock market and other assets, which can be bought and sold
for the in-game currency, FakeCoin. Also includes security software, a
clock app, and a notepad app.
